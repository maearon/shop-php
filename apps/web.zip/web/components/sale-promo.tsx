export default function SalePromo() {
  return (
    <div className="bg-red-600 text-white p-4 text-center">
      <p className="font-bold">UP TO 40% OFF</p>
    </div>
  )
}
