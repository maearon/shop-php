// import React from 'react'

// const TextError: React.FC = (props) => {
//   const divErrorStyle = {color : 'red'}
//   return <div className='error' style={divErrorStyle}>{props.children}</div>
// }

// export default TextError
