import { useCart as useCartContext } from "@/components/Providers"

export const useCart = useCartContext
