// 📁 @types/wish.ts

import type { Product } from '@/@types/product'

export interface WishItem {
  id: number
  product: Product
}
