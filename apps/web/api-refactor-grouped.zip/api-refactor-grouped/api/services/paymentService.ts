// Payment Service API (Stripe-like)

// TODO: Add code here...

// 📦 C:\Users\manhn\code\shop-php\apps\web\api\services\paymentService.ts
// 💳 Payment APIs (Go Gin - payments service)

import api from "@/api/client";

export interface PaymentIntentResponse {
  id: string;
  amount: number;
  currency: string;
  status: string;
}

export interface ConfirmPaymentParams {
  payment_intent_id: string;
  payment_method_id: string;
}

const paymentService = {
  /**
   * 🔧 Create Payment Intent (via Go service)
   */
  async createPaymentIntent(amount: number, currency = "USD"): Promise<PaymentIntentResponse> {
    return api.post("/payments/intent", {
      amount,
      currency,
    });
  },

  /**
   * ✅ Confirm Payment Intent (via Go service)
   */
  async confirmPayment({ payment_intent_id, payment_method_id }: ConfirmPaymentParams): Promise<PaymentIntentResponse> {
    return api.post("/payments/confirm", {
      payment_intent_id,
      payment_method_id,
    });
  },
};

export default paymentService;
