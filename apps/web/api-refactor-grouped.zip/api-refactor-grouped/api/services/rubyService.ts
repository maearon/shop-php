// Ruby Service API (product, cart, order, wish, micropost, relationship)

// TODO: Add code here...

// 📦 Ruby Service API Group (api-ruby)
// Contains all API endpoints and types related to Rails backend:
// - products
// - cart
// - orders
// - wish
// - microposts
// - relationships

import api from "@/api/client"
import { Product, Variant, Size, ProductFilters, ProductsResponse, ProductFollow, FollowResponse, IProductFollow } from "@/@types/product"
import { CartItem, CartCreate, CartShow, CartEdit, UpdateField as CartUpdateField, CartFollow, ICartFollow } from "@/@types/cart"
import { WishItem } from "@/@types/wish"
import { Micropost, ListParams as MicropostListParams, ListResponse as MicropostListResponse } from "@/@types/micropost"
import { RelationshipCreateParams, RelationshipCreateResponse, RelationshipDestroyResponse } from "@/@types/relationship"

// ------------------- Products -------------------
const getProductFilters = () => api.get("/products/filters")

const getProducts = (filters: ProductFilters = {}): Promise<ProductsResponse> => {
  const params = new URLSearchParams()
  Object.entries(filters).forEach(([key, value]) => {
    if (value !== undefined && value !== null && value !== "") {
      params.append(key, value.toString())
    }
  })
  return api.get(`/products${params.toString() ? `?${params.toString()}` : ""}`)
}

const getProduct = (id: number | string, params?: any) => api.get(`/products/${id}`, { params })

const followProduct = (id: string, page: number, action: string): Promise<FollowResponse<ProductFollow, IProductFollow>> => {
  return api.get(`/products/${id}/${action}`, { params: { page } })
}

// ------------------- Orders -------------------
const createOrder = (orderData: {
  shipping_address: any
  billing_address: any
  payment_method: string
}): Promise<any> => api.post("/orders", { order: orderData })

const getOrders = (): Promise<any[]> => api.get("/orders")
const getOrder = (id: number): Promise<any> => api.get(`/orders/${id}`)

// ------------------- Relationships -------------------
const createRelationship = (params: RelationshipCreateParams): Promise<RelationshipCreateResponse> =>
  api.post("/relationships", params)

const destroyRelationship = (id: string): Promise<RelationshipDestroyResponse> =>
  api.delete(`/relationships/${id}`)

export const rubyService = {
  // product
  getProductFilters,
  getProducts,
  getProduct,
  followProduct,

  // order
  createOrder,
  getOrders,
  getOrder,

  // relationship
  createRelationship,
  destroyRelationship,
}
