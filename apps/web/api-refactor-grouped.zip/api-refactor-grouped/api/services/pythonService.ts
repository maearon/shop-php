// Python Service API (search)

// TODO: Add code here...

// 📁 C:\Users\manhn\code\shop-php\apps\web\api\services\pythonService.ts

import api from "@/api/client";
import { Product } from "@/@types/product";
import { SearchFilters, SearchResponse } from "@/@types/search";

const pythonService = {
  // 🔍 Search products using NLP filters (via Django API)
  async searchProducts(filters: SearchFilters = {}): Promise<SearchResponse> {
    return api.post("/search/products", filters);
  }
};

export default pythonService;
