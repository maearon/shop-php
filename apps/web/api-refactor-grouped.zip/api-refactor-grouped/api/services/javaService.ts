// Java Service API (auth, session, user, password reset)

// TODO: Add code here...
// 📦 Java Service (Spring Boot)
// Handles: Auth, Session, User, Password Reset APIs

import api from "@/api/client"
import { SessionResponse, SessionIndexResponse, LoginParams } from "@/@types/auth"
import { ListParams, ListResponse, ShowResponse, User, UserCreateParams, UserCreateResponse, UserEdit, UserShow, UserUpdateParams, UserUpdateResponse } from "@/@types/user"
import { PasswordResetCreateParams, PasswordResetCreateResponse, PasswordResetUpdateParams, PasswordResetUpdateResponse } from "@/@types/auth"

const javaService = {
  // 🔐 Auth
  oauth: (payload: { id_token: string; provider: string }): Promise<SessionResponse> =>
    api.post("/oauth", payload),

  login: (params: LoginParams): Promise<SessionResponse> =>
    api.post("/login", params),

  logout: (): Promise<void> => api.delete("/logout"),

  // 👤 Session
  getCurrentSession: (): Promise<SessionIndexResponse> =>
    api.get("/sessions"),

  // 👤 User
  getUsers: (params: ListParams): Promise<ListResponse<User>> => 
    api.get("/users"),

  async getUser(id: string, params: ListParams): Promise<ShowResponse<UserShow>> {
    const url = `/users/${id}`
    return api.get(url, { params })
  },

  createUser: (params: UserCreateParams): Promise<UserCreateResponse> =>
    api.post("/signup", params),

  updateUser: (id: string, params: UserUpdateParams): Promise<UserUpdateResponse<UserEdit>> =>
    api.patch(`/users/${id}`, params),

  deleteUser: (id: string): Promise<any> =>
    api.delete(`/users/${id}`),

  // 🔄 Password Reset
  createPasswordReset: (params: PasswordResetCreateParams): Promise<PasswordResetCreateResponse> =>
    api.post("/password_resets", params),

  updatePassword: (token: string, params: PasswordResetUpdateParams): Promise<PasswordResetUpdateResponse> =>
    api.patch(`/password_resets/${token}`, params),

  // 📦 Account Activation API (Spring Boot - port 8080)
  // 🔁 Gửi lại email kích hoạt tài khoản
  create: (payload: {
    resend_activation_email: {
      email: string
    }
  }): Promise<{ flash: [string, string] }> => api.post("/account_activations", { email: payload.resend_activation_email.email }),

  // ✅ Kích hoạt tài khoản qua token (đã có từ trước)
  activate: (token: string, email: string): Promise<{ flash: [string, string] }> => api.patch(`/account_activations/${token}/${email}`)

}

export default javaService
